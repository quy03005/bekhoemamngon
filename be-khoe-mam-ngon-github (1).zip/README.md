# Bé khỏe măm ngon — Trang chủ

Giao diện website tiếng Việt cho quán ăn dặm, gồm cháo dinh dưỡng, cơm mềm và nui mềm. Thiết kế responsive, màu xanh lá, trắng và be nhạt.

## Cấu trúc dự án

```text
be-khoe-mam-ngon-github/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── main.js
├── .nojekyll
└── README.md
```

## Chạy thử

Mở trực tiếp `index.html` trong trình duyệt. Không cần cài đặt thư viện hoặc chạy server.

## Đưa lên GitHub Pages

1. Tạo repository mới trên GitHub, ví dụ `be-khoe-mam-ngon`.
2. Tải các file và thư mục **bên trong** dự án này lên **thư mục gốc của repository** (đảm bảo `index.html` nằm ngay cấp gốc).
3. Vào **Settings → Pages**.
4. Trong **Build and deployment**, chọn **Deploy from a branch**.
5. Chọn branch `main`, thư mục `/(root)` và nhấn **Save**.
6. Sau khi triển khai hoàn tất, địa chỉ thông thường là `https://TEN_TAI_KHOAN.github.io/be-khoe-mam-ngon/`.

## Tùy chỉnh

- **Nội dung trang:** `index.html`
- **Màu sắc / bố cục:** `css/style.css`
- **Danh sách món, giá, hình ảnh, giỏ hàng:** `js/main.js`

**Lưu ý:** Giá, hình ảnh và thông tin liên hệ hiện là mẫu minh họa. Ảnh đang lấy từ Unsplash, font từ Google Fonts nên cần Internet để hiển thị đầy đủ. Giỏ hàng chỉ hoạt động trên trang (chưa có backend, cơ sở dữ liệu hoặc thanh toán). Các bài viết hiện là mục giới thiệu mẫu, chưa có trang bài viết chi tiết. Khi dùng thực tế, cần thay hình ảnh đúng món, xác nhận giá và cập nhật thông tin cửa hàng.
